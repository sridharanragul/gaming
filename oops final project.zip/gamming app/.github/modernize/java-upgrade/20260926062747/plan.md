# Upgrade Plan: StudyQuest (20260926062747)

- **Generated**: 2026-09-26 06:27
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required by steps 3 and 5)

**Build Tools**
- Maven Wrapper: 3.9.16 (wrapper present; system Maven is not installed)

> Version control is unavailable because this workspace is not a Git repository. Upgrade changes will remain in the working directory and will not be version-controlled.

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260926062747 (unavailable; workspace is not a Git repository)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target: 25 (latest LTS as of 2026-09-26)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS |
| Spring Boot | 3.3.4 | 3.5.16 | Boot 3.3 does not support Java 25; Boot 3.5.16 supports Java 25 |
| Maven Wrapper | 3.9.16 | 3.6.3 | Current wrapper exceeds Spring Boot 3.5 build minimum |
| Spring Boot-managed dependencies | managed by 3.3.4 | managed by 3.5.16 | Update with the parent to retain compatible versions |

## Derived Upgrades

- Spring Boot parent 3.3.4 → 3.5.16: necessary because Spring Boot 3.5.16 is explicitly compatible with Java 25; this avoids the larger Spring Boot 4 migration.
- No Maven wrapper change: wrapper is already Maven 3.9.16 and Spring Boot 3.5 requires Maven 3.6.3 or later.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | spring-boot-starter-parent | 3.3.4 | upgrade | 3.5.16 | Required Spring Boot line that supports Java 25 |
| pom.xml | java.version | 21 | upgrade | 25 | User-requested runtime/compiler target |
| pom.xml | Spring Boot-managed direct dependencies and spring-boot-maven-plugin | Boot 3.3.4 managed | upgrade | Boot 3.5.16 managed | Parent BOM/plugin management must stay aligned with Java 25-supported Boot |

### Source Code Changes

No Java source changes identified. A compatibility scan found no use of JDK-internal packages, reflective `setAccessible`, or `SecurityManager` in source code.

### Configuration Changes

No Java-version-dependent application configuration changes identified.

### CI/CD Changes

No CI/CD files or JDK-version declarations were found in the workspace.

### Risks & Warnings

- **Spring Boot 3.3.4 to 3.5.16 managed dependency changes**: The parent update advances Spring Framework and other managed dependencies. **Mitigation**: Compile production and test code, run the full test suite under JDK 25, and address any concrete regressions before completion.
- **Baseline unavailable**: JDK 21 is not installed, so a pre-upgrade build/test baseline cannot be recorded. **Mitigation**: Validate compilation and all tests under JDK 25 after the upgrade.
- **Version control unavailable**: The workspace is not a Git repository. **Mitigation**: Keep changes localized to the requested upgrade and record verification in progress/summary artifacts.

### Compatibility Scan Findings

- `pom.xml`, `<properties>`: Java target is 21; change to 25 for the requested LTS runtime.
- `pom.xml`, parent declaration: Spring Boot is 3.3.4 and is below the Java 25-supported 3.5 line; upgrade to 3.5.16.
- `.mvn/wrapper/maven-wrapper.properties`: wrapper distribution is Maven 3.9.16; no change required.
- Source, configuration, metadata, and CI/CD scan: no additional JDK 25 blockers or hardcoded Java versions identified. Build artifacts under `target/` and H2 trace output are generated/runtime data, not source configuration.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: The requested target is JDK 25 and it is not currently installed; Maven Wrapper is available.
  - **Changes to Make**: Install JDK 25. No project file changes.
  - **Verification**: List installed JDKs; confirm JDK 25 is available. Expected: JDK 25 installation path is reported.

- Step 2: Setup Baseline
  - **Rationale**: Record pre-upgrade compilation and test status when the current JDK can be used.
  - **Changes to Make**: No project file changes. Skip because JDK 21 is not installed.
  - **Verification**: Skipped; base JDK unavailable.

- Step 3: Upgrade Java and Compatible Spring Boot Line
  - **Rationale**: Java 25 requires a framework version that officially supports it; the Boot 3.5 line is the minimal compatible migration.
  - **Changes to Make**: Apply all Dependency Changes listed in Impact Analysis.
  - **Verification**: `mvnw.cmd clean test-compile -q`, JDK 25. Expected: production and test compilation succeeds.

- Step 4: CVE Validation and Fix
  - **Rationale**: Check the upgraded direct dependency set for known vulnerabilities and apply available compatible patches.
  - **Changes to Make**: Upgrade only dependencies with reported CVEs, following the CVE pin-protection rules.
  - **Verification**: Scan direct dependencies, compile after any fixes, then rescan. Expected: no reported CVEs with an available compatible fix.

- Step 5: Final Validation
  - **Rationale**: Confirm the requested JDK target, clean compilation, and full test success under the target LTS runtime.
  - **Changes to Make**: Resolve all upgrade-related compilation or test failures; no deferred upgrade work.
  - **Verification**: `mvnw.cmd clean test`, JDK 25. Expected: all tests pass.
