package com.studyquest.controller;

import com.studyquest.model.Badge;
import com.studyquest.model.User;
import com.studyquest.repository.BadgeRepository;
import com.studyquest.repository.StudySessionRepository;
import com.studyquest.repository.UserRepository;
import com.studyquest.service.LevelProgressionService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BadgeRepository badgeRepository;

    @Autowired
    private StudySessionRepository studySessionRepository;

    @Autowired
    private LevelProgressionService levelProgressionService;

    private Long getAuthenticatedUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("USER_ID") == null) {
            return null;
        }
        return (Long) session.getAttribute("USER_ID");
    }

    @GetMapping
    public ResponseEntity<?> getProfile(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        User user = userRepository.findById(userId).orElseThrow();
        user.setPassword(null);

        List<Badge> badges = badgeRepository.findByUserId(userId);
        long nextLevelXp = levelProgressionService.getXpForNextLevel(user.getCurrentLevel());

        Map<String, Object> data = new HashMap<>();
        data.put("user", user);
        data.put("badges", badges);
        data.put("nextLevelXp", nextLevelXp);
        return ResponseEntity.ok(data);
    }

    @PutMapping
    public ResponseEntity<?> updateProfile(@RequestBody User updateReq, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        User user = userRepository.findById(userId).orElseThrow();
        if (updateReq.getName() != null) user.setName(updateReq.getName());
        if (updateReq.getYearOfStudy() != null) user.setYearOfStudy(updateReq.getYearOfStudy());
        if (updateReq.getCourse() != null) user.setCourse(updateReq.getCourse());
        if (updateReq.getCollege() != null) user.setCollege(updateReq.getCollege());
        if (updateReq.getDailyStudyHours() > 0) user.setDailyStudyHours(updateReq.getDailyStudyHours());
        if (updateReq.getPreferredStudyTime() != null) user.setPreferredStudyTime(updateReq.getPreferredStudyTime());
        if (updateReq.getAvatarUrl() != null) user.setAvatarUrl(updateReq.getAvatarUrl());

        User saved = userRepository.save(user);
        saved.setPassword(null);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/onboarding")
    public ResponseEntity<?> completeOnboarding(@RequestBody User onboardingReq, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        User user = userRepository.findById(userId).orElseThrow();
        if (onboardingReq.getName() != null) user.setName(onboardingReq.getName());
        if (onboardingReq.getYearOfStudy() != null) user.setYearOfStudy(onboardingReq.getYearOfStudy());
        if (onboardingReq.getCourse() != null) user.setCourse(onboardingReq.getCourse());
        if (onboardingReq.getCollege() != null) user.setCollege(onboardingReq.getCollege());
        if (onboardingReq.getDailyStudyHours() > 0) user.setDailyStudyHours(onboardingReq.getDailyStudyHours());
        if (onboardingReq.getPreferredStudyTime() != null) user.setPreferredStudyTime(onboardingReq.getPreferredStudyTime());
        user.setOnboardingCompleted(true);

        User saved = userRepository.save(user);
        saved.setPassword(null);
        return ResponseEntity.ok(saved);
    }
}
