package com.studyquest.controller;

import com.studyquest.model.Quest;
import com.studyquest.model.Topic;
import com.studyquest.model.User;
import com.studyquest.repository.QuestRepository;
import com.studyquest.repository.TopicRepository;
import com.studyquest.repository.UserRepository;
import com.studyquest.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/quests")
public class QuestController {

    @Autowired
    private QuestRepository questRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TopicRepository topicRepository;

    @Autowired
    private StudyPlanGeneratorService studyPlanGeneratorService;

    @Autowired
    private LevelProgressionService levelProgressionService;

    @Autowired
    private StreakService streakService;

    @Autowired
    private SmartReschedulingService smartReschedulingService;

    @Autowired
    private RevisionService revisionService;

    private Long getAuthenticatedUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("USER_ID") == null) {
            return null;
        }
        return (Long) session.getAttribute("USER_ID");
    }

    @GetMapping("/today")
    public ResponseEntity<?> getTodaysQuests(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        LocalDate today = LocalDate.now();
        List<Quest> quests = questRepository.findByUserIdAndScheduledDate(userId, today);

        if (quests.isEmpty()) {
            quests = studyPlanGeneratorService.generatePlan(userId);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("date", today);
        response.put("quests", quests);

        long completedCount = quests.stream().filter(Quest::isCompleted).count();
        response.put("allCompleted", !quests.isEmpty() && completedCount == quests.size());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/generate")
    public ResponseEntity<?> generatePlan(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        List<Quest> quests = studyPlanGeneratorService.generatePlan(userId);
        return ResponseEntity.ok(quests);
    }

    @PostMapping("/{id}/complete")
    public ResponseEntity<?> completeQuest(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        Optional<Quest> opt = questRepository.findById(id);
        if (opt.isEmpty() || !opt.get().getUserId().equals(userId)) {
            return ResponseEntity.notFound().build();
        }

        Quest quest = opt.get();
        if (quest.isCompleted()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Quest already completed!"));
        }

        quest.setCompleted(true);
        quest.setCompletedAt(LocalDateTime.now());
        questRepository.save(quest);

        User user = userRepository.findById(userId).orElseThrow();

        // 1. Award XP
        Map<String, Object> xpResult = levelProgressionService.addXp(user, quest.getXpReward());

        // 2. Update Streak
        Map<String, Object> streakResult = streakService.updateStreak(user);

        // 3. Mark topic completed if topicId associated & schedule spaced revision
        if (quest.getTopicId() != null) {
            Optional<Topic> topicOpt = topicRepository.findById(quest.getTopicId());
            if (topicOpt.isPresent()) {
                Topic topic = topicOpt.get();
                topic.setCompleted(true);
                topic.setCompletionDate(LocalDate.now());
                topicRepository.save(topic);

                revisionService.scheduleSpacedRevision(userId, topic);
            }
        }

        Map<String, Object> response = new HashMap<>();
        response.put("quest", quest);
        response.put("xpResult", xpResult);
        response.put("streakResult", streakResult);
        response.put("message", "🎉 Quest Completed! You earned +" + quest.getXpReward() + " XP!");

        return ResponseEntity.ok(response);
    }

    @PostMapping("/reschedule")
    public ResponseEntity<?> reschedule(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        Map<String, Object> result = smartReschedulingService.rescheduleMissedQuests(userId);
        return ResponseEntity.ok(result);
    }
}
