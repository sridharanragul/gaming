package com.studyquest.controller;

import com.studyquest.model.StudySession;
import com.studyquest.model.User;
import com.studyquest.repository.StudySessionRepository;
import com.studyquest.repository.UserRepository;
import com.studyquest.service.LevelProgressionService;
import com.studyquest.service.StreakService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/timer")
public class TimerController {

    @Autowired
    private StudySessionRepository studySessionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LevelProgressionService levelProgressionService;

    @Autowired
    private StreakService streakService;

    public static class SessionRequest {
        private String subjectName;
        private String topicName;
        private int durationMinutes;
        private String mode; // Focus Mode, Deep Study, Custom

        public SessionRequest() {}

        public String getSubjectName() { return subjectName; }
        public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

        public String getTopicName() { return topicName; }
        public void setTopicName(String topicName) { this.topicName = topicName; }

        public int getDurationMinutes() { return durationMinutes; }
        public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

        public String getMode() { return mode; }
        public void setMode(String mode) { this.mode = mode; }
    }

    private Long getAuthenticatedUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("USER_ID") == null) {
            return null;
        }
        return (Long) session.getAttribute("USER_ID");
    }

    @PostMapping("/session")
    public ResponseEntity<?> logSession(@RequestBody SessionRequest req, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        int duration = req.getDurationMinutes() > 0 ? req.getDurationMinutes() : 25;
        int xpEarned;
        if (duration >= 50) xpEarned = 50;
        else if (duration >= 30) xpEarned = 25;
        else if (duration >= 15) xpEarned = 10;
        else xpEarned = 5;

        StudySession session = new StudySession(
            userId,
            (req.getSubjectName() != null) ? req.getSubjectName() : "General Focus",
            (req.getTopicName() != null) ? req.getTopicName() : "Study Session",
            duration,
            xpEarned,
            (req.getMode() != null) ? req.getMode() : "Focus Mode"
        );

        studySessionRepository.save(session);

        User user = userRepository.findById(userId).orElseThrow();
        Map<String, Object> xpResult = levelProgressionService.addXp(user, xpEarned);
        Map<String, Object> streakResult = streakService.updateStreak(user);

        Map<String, Object> response = new HashMap<>();
        response.put("session", session);
        response.put("xpResult", xpResult);
        response.put("streakResult", streakResult);
        response.put("message", "🎉 Focus Quest Complete! Logged " + duration + " mins (+ " + xpEarned + " XP)");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/stats")
    public ResponseEntity<?> getStats(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        List<StudySession> sessions = studySessionRepository.findByUserId(userId);
        LocalDateTime startOfToday = LocalDate.now().atStartOfDay();
        LocalDateTime startOfWeek = LocalDate.now().minusDays(LocalDate.now().getDayOfWeek().getValue() - 1).atStartOfDay();

        int todayMinutes = 0;
        int weekMinutes = 0;
        int totalMinutes = 0;

        for (StudySession s : sessions) {
            totalMinutes += s.getDurationMinutes();
            if (s.getTimestamp().isAfter(startOfWeek)) {
                weekMinutes += s.getDurationMinutes();
            }
            if (s.getTimestamp().isAfter(startOfToday)) {
                todayMinutes += s.getDurationMinutes();
            }
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("todayMinutes", todayMinutes);
        stats.put("weekMinutes", weekMinutes);
        stats.put("totalMinutes", totalMinutes);
        stats.put("sessionsCount", sessions.size());
        stats.put("recentSessions", sessions.stream().sorted((a, b) -> b.getTimestamp().compareTo(a.getTimestamp())).limit(10).toList());

        return ResponseEntity.ok(stats);
    }
}
