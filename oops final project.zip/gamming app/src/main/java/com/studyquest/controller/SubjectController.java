package com.studyquest.controller;

import com.studyquest.model.Subject;
import com.studyquest.model.Topic;
import com.studyquest.repository.SubjectRepository;
import com.studyquest.repository.TopicRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/subjects")
public class SubjectController {

    @Autowired
    private SubjectRepository subjectRepository;

    @Autowired
    private TopicRepository topicRepository;

    private Long getAuthenticatedUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("USER_ID") == null) {
            return null;
        }
        return (Long) session.getAttribute("USER_ID");
    }

    @GetMapping
    public ResponseEntity<?> getSubjects(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        List<Subject> subjects = subjectRepository.findByUserId(userId);
        List<Map<String, Object>> result = new ArrayList<>();

        for (Subject s : subjects) {
            List<Topic> topics = topicRepository.findBySubjectId(s.getId());
            Map<String, Object> map = new HashMap<>();
            map.put("subject", s);
            map.put("topics", topics);
            result.add(map);
        }

        return ResponseEntity.ok(result);
    }

    @PostMapping
    public ResponseEntity<?> addSubject(@RequestBody Subject subject, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        if (subject.getName() == null || subject.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Subject name is required"));
        }

        subject.setUserId(userId);
        Subject saved = subjectRepository.save(subject);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateSubject(@PathVariable Long id, @RequestBody Subject update, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        Optional<Subject> opt = subjectRepository.findById(id);
        if (opt.isEmpty() || !opt.get().getUserId().equals(userId)) {
            return ResponseEntity.notFound().build();
        }

        Subject subject = opt.get();
        if (update.getName() != null) subject.setName(update.getName());
        if (update.getDifficulty() != null) subject.setDifficulty(update.getDifficulty());
        if (update.getExamDate() != null) subject.setExamDate(update.getExamDate());
        if (update.getCurrentKnowledgeLevel() > 0) subject.setCurrentKnowledgeLevel(update.getCurrentKnowledgeLevel());
        if (update.getImportantTopics() != null) subject.setImportantTopics(update.getImportantTopics());
        if (update.getColor() != null) subject.setColor(update.getColor());

        Subject saved = subjectRepository.save(subject);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSubject(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        Optional<Subject> opt = subjectRepository.findById(id);
        if (opt.isEmpty() || !opt.get().getUserId().equals(userId)) {
            return ResponseEntity.notFound().build();
        }

        List<Topic> topics = topicRepository.findBySubjectId(id);
        topicRepository.deleteAll(topics);
        subjectRepository.deleteById(id);

        return ResponseEntity.ok(Map.of("message", "Subject and related topics deleted."));
    }

    @PostMapping("/{subjectId}/topics")
    public ResponseEntity<?> addTopic(@PathVariable Long subjectId, @RequestBody Topic topic, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        Optional<Subject> opt = subjectRepository.findById(subjectId);
        if (opt.isEmpty() || !opt.get().getUserId().equals(userId)) {
            return ResponseEntity.notFound().build();
        }

        if (topic.getName() == null || topic.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Topic name is required"));
        }

        topic.setSubjectId(subjectId);
        topic.setUserId(userId);
        Topic saved = topicRepository.save(topic);
        return ResponseEntity.ok(saved);
    }
}
