package com.studyquest.controller;

import com.studyquest.model.User;
import com.studyquest.repository.UserRepository;
import com.studyquest.service.LevelProgressionService;
import com.studyquest.service.QuizService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/adventure")
public class AdventureController {

    @Autowired
    private LevelProgressionService levelProgressionService;

    @Autowired
    private QuizService quizService;

    @Autowired
    private UserRepository userRepository;

    private Long getAuthenticatedUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("USER_ID") == null) {
            return null;
        }
        return (Long) session.getAttribute("USER_ID");
    }

    @GetMapping("/map")
    public ResponseEntity<?> getAdventureMap(HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        User user = userRepository.findById(userId).orElseThrow();
        List<LevelProgressionService.LevelData> levels = levelProgressionService.getAll100Levels(user.getCurrentLevel());

        Map<String, Object> mapData = new HashMap<>();
        mapData.put("currentLevel", user.getCurrentLevel());
        mapData.put("totalXp", user.getTotalXp());
        mapData.put("nextLevelXp", levelProgressionService.getXpForNextLevel(user.getCurrentLevel()));
        mapData.put("levels", levels);

        return ResponseEntity.ok(mapData);
    }

    @GetMapping("/boss-quiz/{level}")
    public ResponseEntity<?> getBossQuiz(@PathVariable int level, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        List<QuizService.QuizQuestion> questions = quizService.generateBossChallenge(userId, level);
        return ResponseEntity.ok(questions);
    }

    public static class QuizSubmitRequest {
        private int questionIndex;
        private int selectedIndex;
        private int correctIndex;

        public QuizSubmitRequest() {}

        public int getQuestionIndex() { return questionIndex; }
        public void setQuestionIndex(int questionIndex) { this.questionIndex = questionIndex; }

        public int getSelectedIndex() { return selectedIndex; }
        public void setSelectedIndex(int selectedIndex) { this.selectedIndex = selectedIndex; }

        public int getCorrectIndex() { return correctIndex; }
        public void setCorrectIndex(int correctIndex) { this.correctIndex = correctIndex; }
    }

    @PostMapping("/boss-quiz/submit")
    public ResponseEntity<?> submitQuizAnswer(@RequestBody QuizSubmitRequest req, HttpServletRequest request) {
        Long userId = getAuthenticatedUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Not authenticated"));

        boolean isCorrect = (req.getSelectedIndex() == req.getCorrectIndex());
        Map<String, Object> response = new HashMap<>();
        response.put("correct", isCorrect);

        if (isCorrect) {
            User user = userRepository.findById(userId).orElseThrow();
            Map<String, Object> xpResult = levelProgressionService.addXp(user, 30);
            response.put("xpResult", xpResult);
            response.put("message", "⚔️ Correct! You conquered this challenge and earned +30 XP!");
        } else {
            response.put("message", "Incorrect answer. Review the concept and try again!");
        }

        return ResponseEntity.ok(response);
    }
}
