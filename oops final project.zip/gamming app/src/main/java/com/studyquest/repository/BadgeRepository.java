package com.studyquest.repository;

import com.studyquest.model.Badge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BadgeRepository extends JpaRepository<Badge, Long> {
    List<Badge> findByUserId(Long userId);
    Optional<Badge> findByUserIdAndBadgeKey(Long userId, String badgeKey);
    boolean existsByUserIdAndBadgeKey(Long userId, String badgeKey);
}
