package com.studyquest.repository;

import com.studyquest.model.Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TopicRepository extends JpaRepository<Topic, Long> {
    List<Topic> findByUserId(Long userId);
    List<Topic> findBySubjectId(Long subjectId);
    List<Topic> findByUserIdAndIsCompleted(Long userId, boolean isCompleted);
}
