package com.studyquest.repository;

import com.studyquest.model.Quest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface QuestRepository extends JpaRepository<Quest, Long> {
    List<Quest> findByUserId(Long userId);
    List<Quest> findByUserIdAndScheduledDate(Long userId, LocalDate scheduledDate);
    List<Quest> findByUserIdAndScheduledDateAndCompleted(Long userId, LocalDate scheduledDate, boolean completed);
    List<Quest> findByUserIdAndScheduledDateBeforeAndCompleted(Long userId, LocalDate scheduledDate, boolean completed);
    List<Quest> findByUserIdAndCompleted(Long userId, boolean completed);
}
