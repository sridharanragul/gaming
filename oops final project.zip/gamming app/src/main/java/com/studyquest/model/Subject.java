package com.studyquest.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "subjects")
public class Subject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String name;

    private String difficulty = "Medium";
    private LocalDate examDate;
    private int currentKnowledgeLevel = 5;
    private String importantTopics;
    private String color = "#6366f1";

    public Subject() {}

    public Subject(Long userId, String name, String difficulty, LocalDate examDate, int currentKnowledgeLevel) {
        this.userId = userId;
        this.name = name;
        this.difficulty = difficulty;
        this.examDate = examDate;
        this.currentKnowledgeLevel = currentKnowledgeLevel;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public LocalDate getExamDate() { return examDate; }
    public void setExamDate(LocalDate examDate) { this.examDate = examDate; }

    public int getCurrentKnowledgeLevel() { return currentKnowledgeLevel; }
    public void setCurrentKnowledgeLevel(int currentKnowledgeLevel) { this.currentKnowledgeLevel = currentKnowledgeLevel; }

    public String getImportantTopics() { return importantTopics; }
    public void setImportantTopics(String importantTopics) { this.importantTopics = importantTopics; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
}
