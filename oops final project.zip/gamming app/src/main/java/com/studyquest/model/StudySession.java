package com.studyquest.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "study_sessions")
public class StudySession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    private String subjectName;
    private String topicName;
    private int durationMinutes;
    private int xpEarned;
    private String mode = "Focus Mode"; // Focus Mode, Deep Study, Custom

    private LocalDateTime timestamp = LocalDateTime.now();

    public StudySession() {}

    public StudySession(Long userId, String subjectName, String topicName, int durationMinutes, int xpEarned, String mode) {
        this.userId = userId;
        this.subjectName = subjectName;
        this.topicName = topicName;
        this.durationMinutes = durationMinutes;
        this.xpEarned = xpEarned;
        this.mode = mode;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getTopicName() { return topicName; }
    public void setTopicName(String topicName) { this.topicName = topicName; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public int getXpEarned() { return xpEarned; }
    public void setXpEarned(int xpEarned) { this.xpEarned = xpEarned; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
