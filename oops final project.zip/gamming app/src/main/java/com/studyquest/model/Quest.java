package com.studyquest.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "quests")
public class Quest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    private Long subjectId;
    private Long topicId;

    @Column(nullable = false)
    private String title;

    private String subjectName;
    private String topicName;
    private String learningMethod;
    private int durationMinutes = 30;
    private int xpReward = 25;

    @Column(nullable = false)
    private LocalDate scheduledDate;

    private boolean completed = false;
    private LocalDateTime completedAt;
    private boolean isRevision = false;
    private boolean isRescheduled = false;
    private String questType = "DAILY"; // DAILY, REVISION, BOSS_CHALLENGE, LEVEL_MISSION

    public Quest() {}

    public Quest(Long userId, String title, String subjectName, String learningMethod, int durationMinutes, int xpReward, LocalDate scheduledDate) {
        this.userId = userId;
        this.title = title;
        this.subjectName = subjectName;
        this.learningMethod = learningMethod;
        this.durationMinutes = durationMinutes;
        this.xpReward = xpReward;
        this.scheduledDate = scheduledDate;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getSubjectId() { return subjectId; }
    public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }

    public Long getTopicId() { return topicId; }
    public void setTopicId(Long topicId) { this.topicId = topicId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getTopicName() { return topicName; }
    public void setTopicName(String topicName) { this.topicName = topicName; }

    public String getLearningMethod() { return learningMethod; }
    public void setLearningMethod(String learningMethod) { this.learningMethod = learningMethod; }

    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }

    public int getXpReward() { return xpReward; }
    public void setXpReward(int xpReward) { this.xpReward = xpReward; }

    public LocalDate getScheduledDate() { return scheduledDate; }
    public void setScheduledDate(LocalDate scheduledDate) { this.scheduledDate = scheduledDate; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public boolean isRevision() { return isRevision; }
    public void setRevision(boolean revision) { isRevision = revision; }

    public boolean isRescheduled() { return isRescheduled; }
    public void setRescheduled(boolean rescheduled) { isRescheduled = rescheduled; }

    public String getQuestType() { return questType; }
    public void setQuestType(String questType) { this.questType = questType; }
}
