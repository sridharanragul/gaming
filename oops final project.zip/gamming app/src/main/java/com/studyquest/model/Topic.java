package com.studyquest.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "topics")
public class Topic {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long subjectId;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String name;

    private String chapter;
    private boolean isImportant = false;
    private boolean isCompleted = false;
    private LocalDate completionDate;
    private String recommendedMethod = "Read concepts";

    public Topic() {}

    public Topic(Long subjectId, Long userId, String name, String chapter, boolean isImportant) {
        this.subjectId = subjectId;
        this.userId = userId;
        this.name = name;
        this.chapter = chapter;
        this.isImportant = isImportant;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSubjectId() { return subjectId; }
    public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getChapter() { return chapter; }
    public void setChapter(String chapter) { this.chapter = chapter; }

    public boolean isImportant() { return isImportant; }
    public void setImportant(boolean important) { isImportant = important; }

    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { isCompleted = completed; }

    public LocalDate getCompletionDate() { return completionDate; }
    public void setCompletionDate(LocalDate completionDate) { this.completionDate = completionDate; }

    public String getRecommendedMethod() { return recommendedMethod; }
    public void setRecommendedMethod(String recommendedMethod) { this.recommendedMethod = recommendedMethod; }
}
