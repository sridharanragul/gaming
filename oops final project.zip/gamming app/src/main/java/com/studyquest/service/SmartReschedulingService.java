package com.studyquest.service;

import com.studyquest.model.Quest;
import com.studyquest.repository.QuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class SmartReschedulingService {

    @Autowired
    private QuestRepository questRepository;

    public Map<String, Object> rescheduleMissedQuests(Long userId) {
        LocalDate today = LocalDate.now();
        List<Quest> missedQuests = questRepository.findByUserIdAndScheduledDateBeforeAndCompleted(userId, today, false);

        int rescheduledCount = 0;
        List<String> movedTitles = new ArrayList<>();

        for (Quest quest : missedQuests) {
            quest.setScheduledDate(today);
            quest.setRescheduled(true);
            movedTitles.add(quest.getTitle());
            questRepository.save(quest);
            rescheduledCount++;
        }

        Map<String, Object> response = new HashMap<>();
        response.put("rescheduledCount", rescheduledCount);
        response.put("movedTitles", movedTitles);
        if (rescheduledCount > 0) {
            response.put("message", "⚠️ Unfinished Quest detected: We have moved " + rescheduledCount + " quest(s) to today's schedule without breaking your momentum!");
        } else {
            response.put("message", "All past quests are up to date! Keep up the awesome momentum!");
        }
        return response;
    }
}
