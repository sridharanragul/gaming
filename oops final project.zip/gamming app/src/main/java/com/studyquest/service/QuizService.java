package com.studyquest.service;

import com.studyquest.model.Subject;
import com.studyquest.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class QuizService {

    @Autowired
    private SubjectRepository subjectRepository;

    public static class QuizQuestion {
        public String question;
        public List<String> options;
        public int correctIndex;
        public String explanation;
        public int xpReward = 30;

        public QuizQuestion(String question, List<String> options, int correctIndex, String explanation) {
            this.question = question;
            this.options = options;
            this.correctIndex = correctIndex;
            this.explanation = explanation;
        }
    }

    public List<QuizQuestion> generateBossChallenge(Long userId, int level) {
        List<Subject> subjects = subjectRepository.findByUserId(userId);
        String subjectName = (!subjects.isEmpty()) ? subjects.get(0).getName() : "Computer Science & General Knowledge";

        List<QuizQuestion> questions = new ArrayList<>();

        if (level % 10 == 0 || level == 1) {
            questions.add(new QuizQuestion(
                "⚔️ Boss Question 1: What is the time complexity of searching in a balanced Binary Search Tree (BST)?",
                Arrays.asList("O(1)", "O(n)", "O(log n)", "O(n log n)"),
                2,
                "In a balanced BST, the height of the tree is O(log n), so search operations halve the search space at each step!"
            ));
            questions.add(new QuizQuestion(
                "⚔️ Boss Question 2: Which data structure operates on a First-In, First-Out (FIFO) basis?",
                Arrays.asList("Stack", "Queue", "Tree", "Graph"),
                1,
                "A Queue processes items in the order they were added (FIFO), just like a real-life waiting line!"
            ));
            questions.add(new QuizQuestion(
                "⚔️ Boss Question 3: In Operating Systems, what occurs when two processes wait infinitely for resources held by each other?",
                Arrays.asList("Paging", "Deadlock", "Thrashing", "Context Switching"),
                1,
                "Deadlock occurs when processes hold resources while waiting for other resources in a circular dependency loop."
            ));
        } else {
            questions.add(new QuizQuestion(
                "🎯 Mini Quiz (" + subjectName + "): What is the best technique to review learned concepts over increasing time intervals?",
                Arrays.asList("Cramming overnight", "Spaced Repetition", "Reading fast once", "Highlighting everything"),
                1,
                "Spaced repetition leverages the psychological spacing effect to dramatically enhance long-term memory retention!"
            ));
        }

        return questions;
    }
}
