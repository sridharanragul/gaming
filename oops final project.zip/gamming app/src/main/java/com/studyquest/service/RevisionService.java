package com.studyquest.service;

import com.studyquest.model.Quest;
import com.studyquest.model.Topic;
import com.studyquest.repository.QuestRepository;
import com.studyquest.repository.TopicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class RevisionService {

    @Autowired
    private QuestRepository questRepository;

    @Autowired
    private TopicRepository topicRepository;

    public void scheduleSpacedRevision(Long userId, Topic topic) {
        LocalDate today = LocalDate.now();
        int[] revisionIntervals = {1, 3, 7, 14};

        for (int days : revisionIntervals) {
            LocalDate revisionDate = today.plusDays(days);
            Quest revisionQuest = new Quest(
                userId,
                "🔄 REVISION QUEST: " + topic.getName(),
                "Revision",
                "Spaced repetition review of " + topic.getName(),
                20,
                30,
                revisionDate
            );
            revisionQuest.setTopicId(topic.getId());
            revisionQuest.setSubjectId(topic.getSubjectId());
            revisionQuest.setRevision(true);
            revisionQuest.setQuestType("REVISION");
            questRepository.save(revisionQuest);
        }
    }
}
