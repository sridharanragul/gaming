package com.studyquest.service;

import com.studyquest.model.Quest;
import com.studyquest.model.Subject;
import com.studyquest.model.Topic;
import com.studyquest.model.User;
import com.studyquest.repository.QuestRepository;
import com.studyquest.repository.SubjectRepository;
import com.studyquest.repository.TopicRepository;
import com.studyquest.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class StudyPlanGeneratorService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SubjectRepository subjectRepository;

    @Autowired
    private TopicRepository topicRepository;

    @Autowired
    private QuestRepository questRepository;

    private static final String[] LEARNING_METHODS = {
        "Read concepts & chapter notes",
        "Watch video lecture",
        "Make concise summary notes",
        "Practice core examples",
        "Solve coding / numerical problems",
        "Revise key concepts",
        "Take quick self-quiz",
        "Practice previous exam questions"
    };

    public List<Quest> generatePlan(Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        List<Subject> subjects = subjectRepository.findByUserId(userId);
        List<Topic> topics = topicRepository.findByUserId(userId);

        if (subjects.isEmpty()) return Collections.emptyList();

        double dailyHours = user.getDailyStudyHours() > 0 ? user.getDailyStudyHours() : 3.0;
        int totalDailyMinutes = (int) (dailyHours * 60);

        // Filter uncompleted topics
        List<Topic> pendingTopics = new ArrayList<>(topics.stream().filter(t -> !t.isCompleted()).toList());

        // Sort subjects by urgency: Difficulty + proximity of exam date
        LocalDate today = LocalDate.now();
        subjects.sort((s1, s2) -> {
            int score1 = calculateUrgencyScore(s1, today);
            int score2 = calculateUrgencyScore(s2, today);
            return Integer.compare(score2, score1); // Descending score
        });

        // Clear existing future uncompleted quests for user
        List<Quest> existingUncompleted = questRepository.findByUserIdAndScheduledDateAndCompleted(userId, today, false);
        questRepository.deleteAll(existingUncompleted);

        List<Quest> generatedQuests = new ArrayList<>();
        int allocatedMinutes = 0;
        Random random = new Random();

        // Always include 1 Revision Quest if possible
        Quest revisionQuest = new Quest(
            userId,
            "🔄 Revision Quest: Daily Recap",
            "General Revision",
            "Revise previous notes & formulas",
            20,
            25,
            today
        );
        revisionQuest.setRevision(true);
        revisionQuest.setQuestType("REVISION");
        generatedQuests.add(revisionQuest);
        allocatedMinutes += 20;

        // Distribute remaining minutes among subjects
        int subjectIndex = 0;
        int topicIdx = 0;

        while (allocatedMinutes < totalDailyMinutes - 15) {
            Subject activeSubject = subjects.get(subjectIndex % subjects.size());
            int sessionDuration;
            if (totalDailyMinutes - allocatedMinutes >= 60) {
                sessionDuration = 45;
            } else if (totalDailyMinutes - allocatedMinutes >= 30) {
                sessionDuration = 30;
            } else {
                sessionDuration = Math.max(15, totalDailyMinutes - allocatedMinutes);
            }

            Topic targetTopic = null;
            if (!pendingTopics.isEmpty()) {
                // Find topic matching active subject
                Optional<Topic> match = pendingTopics.stream()
                        .filter(t -> t.getSubjectId().equals(activeSubject.getId()))
                        .findFirst();
                if (match.isPresent()) {
                    targetTopic = match.get();
                    pendingTopics.remove(targetTopic);
                }
            }

            String topicName = (targetTopic != null) ? targetTopic.getName() : "Core Concepts & Exercises";
            String method = (targetTopic != null && targetTopic.getRecommendedMethod() != null)
                    ? targetTopic.getRecommendedMethod()
                    : LEARNING_METHODS[random.nextInt(LEARNING_METHODS.length)];

            String title = "⚔️ Quest: " + activeSubject.getName() + " - " + topicName;
            int xp = Math.max(15, (sessionDuration / 15) * 15);

            Quest quest = new Quest(
                userId,
                title,
                activeSubject.getName(),
                method,
                sessionDuration,
                xp,
                today
            );
            quest.setSubjectId(activeSubject.getId());
            if (targetTopic != null) quest.setTopicId(targetTopic.getId());
            quest.setTopicName(topicName);

            generatedQuests.add(quest);
            allocatedMinutes += sessionDuration;
            subjectIndex++;
        }

        // Save generated quests
        List<Quest> savedQuests = questRepository.saveAll(generatedQuests);
        return savedQuests;
    }

    private int calculateUrgencyScore(Subject subject, LocalDate today) {
        int score = 0;
        if ("Boss Level".equalsIgnoreCase(subject.getDifficulty()) || "Hard".equalsIgnoreCase(subject.getDifficulty())) {
            score += 30;
        } else if ("Medium".equalsIgnoreCase(subject.getDifficulty())) {
            score += 20;
        } else {
            score += 10;
        }

        if (subject.getExamDate() != null) {
            long daysUntilExam = ChronoUnit.DAYS.between(today, subject.getExamDate());
            if (daysUntilExam <= 3) score += 50;
            else if (daysUntilExam <= 7) score += 35;
            else if (daysUntilExam <= 14) score += 20;
            else if (daysUntilExam <= 30) score += 10;
        }

        return score;
    }
}
