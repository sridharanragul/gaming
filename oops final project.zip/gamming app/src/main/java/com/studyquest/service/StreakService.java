package com.studyquest.service;

import com.studyquest.model.Badge;
import com.studyquest.model.User;
import com.studyquest.repository.BadgeRepository;
import com.studyquest.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class StreakService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BadgeRepository badgeRepository;

    public Map<String, Object> updateStreak(User user) {
        LocalDate today = LocalDate.now();
        LocalDate lastDate = user.getLastStudyDate();

        boolean streakReset = false;
        String streakMessage;

        if (lastDate == null) {
            user.setCurrentStreak(1);
            user.setLongestStreak(1);
            streakMessage = "Your quest begins today! 1 Day Streak 🔥";
        } else if (lastDate.equals(today)) {
            // Already studied today
            streakMessage = "Streak maintained for today! 🔥 " + user.getCurrentStreak() + " Days";
        } else if (lastDate.equals(today.minusDays(1))) {
            // Studied yesterday
            int newStreak = user.getCurrentStreak() + 1;
            user.setCurrentStreak(newStreak);
            if (newStreak > user.getLongestStreak()) {
                user.setLongestStreak(newStreak);
            }
            streakMessage = "Streak On Fire! 🔥 " + newStreak + " Days";
        } else {
            // Missed one or more days
            streakReset = true;
            user.setCurrentStreak(1);
            streakMessage = "Your quest can begin again today! Let's build a new streak! 🔥 1 Day";
        }

        user.setLastStudyDate(today);
        userRepository.save(user);

        // Check streak badges
        checkStreakBadges(user);

        Map<String, Object> result = new HashMap<>();
        result.put("currentStreak", user.getCurrentStreak());
        result.put("longestStreak", user.getLongestStreak());
        result.put("streakReset", streakReset);
        result.put("message", streakMessage);
        return result;
    }

    private void checkStreakBadges(User user) {
        int streak = user.getCurrentStreak();
        Long uId = user.getId();

        if (streak >= 3 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_3")) {
            badgeRepository.save(new Badge(uId, "STREAK_3", "Bronze Warrior", "Maintain a 3-day study streak", "🥉"));
        }
        if (streak >= 7 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_7")) {
            badgeRepository.save(new Badge(uId, "STREAK_7", "Silver Scholar", "Maintain a 7-day study streak", "🥈"));
        }
        if (streak >= 14 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_14")) {
            badgeRepository.save(new Badge(uId, "STREAK_14", "Gold Conqueror", "Maintain a 14-day study streak", "🥇"));
        }
        if (streak >= 30 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_30")) {
            badgeRepository.save(new Badge(uId, "STREAK_30", "Fire Master", "Maintain a 30-day study streak", "🔥"));
        }
        if (streak >= 60 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_60")) {
            badgeRepository.save(new Badge(uId, "STREAK_60", "Study Warrior", "Maintain a 60-day study streak", "⚔️"));
        }
        if (streak >= 100 && !badgeRepository.existsByUserIdAndBadgeKey(uId, "STREAK_100")) {
            badgeRepository.save(new Badge(uId, "STREAK_100", "Legendary Scholar", "Maintain a 100-day study streak", "👑"));
        }
    }
}
