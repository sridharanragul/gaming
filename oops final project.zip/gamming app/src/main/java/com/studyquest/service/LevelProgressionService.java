package com.studyquest.service;

import com.studyquest.model.User;
import com.studyquest.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LevelProgressionService {

    @Autowired
    private UserRepository userRepository;

    public static class LevelData {
        public int level;
        public String title;
        public String zoneName;
        public String icon;
        public long xpRequired;
        public String mission;
        public String rewardBadgeKey;
        public String rewardBadgeTitle;
        public boolean unlocked;

        public LevelData(int level, String title, String zoneName, String icon, long xpRequired, String mission, String rewardBadgeKey, String rewardBadgeTitle) {
            this.level = level;
            this.title = title;
            this.zoneName = zoneName;
            this.icon = icon;
            this.xpRequired = xpRequired;
            this.mission = mission;
            this.rewardBadgeKey = rewardBadgeKey;
            this.rewardBadgeTitle = rewardBadgeTitle;
        }
    }

    public long getXpForNextLevel(int currentLevel) {
        if (currentLevel >= 100) return 500000;
        return (long) (200 * currentLevel + Math.pow(currentLevel, 1.4) * 50);
    }

    public List<LevelData> getAll100Levels(int userLevel) {
        List<LevelData> levels = new ArrayList<>();

        for (int i = 1; i <= 100; i++) {
            String zone;
            String icon;
            if (i <= 9) { zone = "Starting Village"; icon = "🏕️"; }
            else if (i <= 19) { zone = "Knowledge Forest"; icon = "🌲"; }
            else if (i <= 29) { zone = "Mountain of Concepts"; icon = "🏔️"; }
            else if (i <= 39) { zone = "Castle of Coding"; icon = "🏰"; }
            else if (i <= 49) { zone = "Volcano of Challenges"; icon = "🌋"; }
            else if (i <= 59) { zone = "Galaxy of Knowledge"; icon = "🌌"; }
            else if (i <= 69) { zone = "Temple of Mastery"; icon = "🏯"; }
            else if (i <= 79) { zone = "Warrior's Challenge"; icon = "⚔️"; }
            else if (i <= 89) { zone = "Dragon's Exam"; icon = "🐉"; }
            else if (i <= 99) { zone = "Kingdom of Knowledge"; icon = "👑"; }
            else { zone = "Study Master Realm"; icon = "🏆"; }

            String title;
            if (i == 1) title = "First Step Novice";
            else if (i == 10) title = "Forest Explorer";
            else if (i == 20) title = "Mountain Climber";
            else if (i == 30) title = "Code Architect";
            else if (i == 40) title = "Challenge Conqueror";
            else if (i == 50) title = "Starlight Scholar";
            else if (i == 60) title = "Grand Master";
            else if (i == 70) title = "Battle Scholar";
            else if (i == 80) title = "Dragon Slayer";
            else if (i == 90) title = "Crown Royal";
            else if (i == 100) title = "Ultimate Study Master";
            else title = zone + " Stage " + i;

            long reqXp = getXpForNextLevel(i);
            int minMinutes = 15 + (i * 2);
            int tasks = 1 + (i / 10);
            String mission = "Study for " + minMinutes + " mins & complete " + tasks + " quest(s)";

            String badgeKey = null;
            String badgeTitle = null;
            if (i == 1) { badgeKey = "FIRST_STEP"; badgeTitle = "First Step"; }
            else if (i == 10) { badgeKey = "FOREST_NAVIGATOR"; badgeTitle = "Forest Navigator"; }
            else if (i == 25) { badgeKey = "CONCEPT_MASTER"; badgeTitle = "Concept Master"; }
            else if (i == 50) { badgeKey = "GALAXY_SCHOLAR"; badgeTitle = "Galaxy Scholar"; }
            else if (i == 75) { badgeKey = "WARRIOR_VALOR"; badgeTitle = "Warrior's Valor"; }
            else if (i == 100) { badgeKey = "STUDY_MASTER"; badgeTitle = "Study Master"; }

            LevelData data = new LevelData(i, title, zone, icon, reqXp, mission, badgeKey, badgeTitle);
            data.unlocked = (i <= userLevel);
            levels.add(data);
        }

        return levels;
    }

    public Map<String, Object> addXp(User user, int xp) {
        long oldXp = user.getTotalXp();
        int oldLevel = user.getCurrentLevel();
        long newXp = oldXp + xp;
        user.setTotalXp(newXp);

        int newLevel = oldLevel;
        while (newLevel < 100 && newXp >= getXpForNextLevel(newLevel)) {
            newLevel++;
        }

        boolean leveledUp = newLevel > oldLevel;
        user.setCurrentLevel(newLevel);
        userRepository.save(user);

        Map<String, Object> result = new HashMap<>();
        result.put("oldXp", oldXp);
        result.put("newXp", newXp);
        result.put("xpAdded", xp);
        result.put("oldLevel", oldLevel);
        result.put("newLevel", newLevel);
        result.put("leveledUp", leveledUp);
        result.put("nextLevelXp", getXpForNextLevel(newLevel));
        return result;
    }
}
