/* ==========================================================================
   StudyQuest - Gamified Personal Study Application Logic
   ========================================================================== */

let currentUser = null;
let currentView = 'home';
let onboardingStep = 2;
let tempOnboardingData = {
  name: '',
  yearOfStudy: '2nd Year',
  course: 'B.Tech CSBS',
  college: '',
  dailyStudyHours: 3.0,
  preferredStudyTime: 'Evening',
  subjects: []
};

// Timer State
let timerInterval = null;
let timerSeconds = 1500; // 25 mins default
let timerTotalSeconds = 1500;
let isTimerRunning = false;
let currentTimerMode = 'FOCUS'; // FOCUS (25), DEEP (50), CUSTOM

// Web Audio API Sound Synthesizer
function playChimeSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
    osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.3); // E5
    osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.6); // G5
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.9);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.9);
  } catch (e) { console.log("Audio play error", e); }
}

// ==========================================================================
// INITIALIZATION
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  if (localStorage.getItem('sq_theme') === 'light') {
    document.body.classList.add('light-mode');
  }
});

function toggleTheme() {
  document.body.classList.toggle('light-mode');
  const isLight = document.body.classList.contains('light-mode');
  localStorage.setItem('sq_theme', isLight ? 'light' : 'dark');
}

// ==========================================================================
// AUTHENTICATION
// ==========================================================================
async function checkAuth() {
  try {
    const res = await fetch('/api/auth/me');
    if (res.ok) {
      currentUser = await res.json();
      document.getElementById('auth-screen').style.display = 'none';

      if (!currentUser.onboardingCompleted) {
        startOnboardingWizard();
      } else {
        document.getElementById('app-container').style.display = 'flex';
        updateNavProfile();
        loadHomeData();
      }
    } else {
      document.getElementById('auth-screen').style.display = 'flex';
      document.getElementById('app-container').style.display = 'none';
    }
  } catch (err) {
    document.getElementById('auth-screen').style.display = 'flex';
  }
}

let authMode = 'login';
function switchAuthTab(mode) {
  authMode = mode;
  document.getElementById('tab-btn-login').className = mode === 'login' ? 'btn btn-primary' : 'btn btn-secondary';
  document.getElementById('tab-btn-signup').className = mode === 'signup' ? 'btn btn-primary' : 'btn btn-secondary';
  
  document.getElementById('auth-name-group').style.display = mode === 'signup' ? 'block' : 'none';
  document.getElementById('auth-email-group').style.display = mode === 'signup' ? 'block' : 'none';
  document.getElementById('auth-submit-btn').innerText = mode === 'signup' ? 'Create Account & Begin 🚀' : 'Login to Adventure 🔑';
}

async function handleAuthSubmit(e) {
  e.preventDefault();
  const username = document.getElementById('auth-username').value;
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-name').value;
  const email = document.getElementById('auth-email').value;
  const errorEl = document.getElementById('auth-error-msg');
  errorEl.style.display = 'none';

  const endpoint = authMode === 'signup' ? '/api/auth/register' : '/api/auth/login';
  const bodyData = authMode === 'signup' 
    ? { username, email, password, name }
    : { username, password };

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyData)
    });
    const data = await res.json();

    if (res.ok) {
      currentUser = data;
      document.getElementById('auth-screen').style.display = 'none';
      if (!currentUser.onboardingCompleted) {
        startOnboardingWizard();
      } else {
        document.getElementById('app-container').style.display = 'flex';
        updateNavProfile();
        loadHomeData();
      }
    } else {
      errorEl.innerText = data.error || 'Authentication failed.';
      errorEl.style.display = 'block';
    }
  } catch (err) {
    errorEl.innerText = 'Server connection error. Please try again.';
    errorEl.style.display = 'block';
  }
}

async function logout() {
  await fetch('/api/auth/logout', { method: 'POST' });
  currentUser = null;
  location.reload();
}

function updateNavProfile() {
  if (!currentUser) return;
  document.getElementById('nav-user-name').innerText = currentUser.name || currentUser.username;
  document.getElementById('nav-user-lvl').innerText = 'Level ' + currentUser.currentLevel;
  document.getElementById('nav-user-avatar').innerText = currentUser.avatarUrl || '🧙‍♂️';
}

// ==========================================================================
// ONBOARDING WIZARD (STEPS 1 - 8)
// ==========================================================================
function startOnboardingWizard() {
  onboardingStep = 2;
  document.getElementById('onboarding-screen').classList.add('active');
  renderOnboardingStep();
}

function renderOnboardingStep() {
  const container = document.getElementById('onboarding-step-content');

  if (onboardingStep === 2) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 2.5rem;">🎓</span>
        <h2 style="font-weight: 800;">Step 2 of 8: Student Profile</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">Tell StudyQuest about your academic journey</p>
      </div>
      <div class="form-group">
        <label>Your Full Name</label>
        <input type="text" id="onb-name" class="form-control" value="${currentUser.name || ''}" placeholder="e.g. Thanuja">
      </div>
      <div class="form-group">
        <label>Year of Study</label>
        <input type="text" id="onb-year" class="form-control" value="2nd Year" placeholder="e.g. 2nd Year">
      </div>
      <div class="form-group">
        <label>Course / Degree</label>
        <input type="text" id="onb-course" class="form-control" value="B.Tech CSBS" placeholder="e.g. B.Tech CSBS">
      </div>
      <div class="form-group">
        <label>College Name (Optional)</label>
        <input type="text" id="onb-college" class="form-control" placeholder="e.g. SRM Institute of Technology">
      </div>
      <button onclick="saveOnboardingStep2()" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Next: What are you studying? ➡️</button>
    `;
  } else if (onboardingStep === 3) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 2.5rem;">📚</span>
        <h2 style="font-weight: 800;">Step 3 of 8: What are you studying?</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">Add your current subjects/courses</p>
      </div>
      <div id="onb-subj-list" style="margin-bottom: 1rem; display: flex; flex-direction: column; gap: 0.5rem;"></div>
      <div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem;">
        <input type="text" id="onb-new-subj" class="form-control" placeholder="Subject Name (e.g. Data Structures)">
        <select id="onb-new-diff" class="form-control" style="width: 130px;">
          <option value="Easy">Easy</option>
          <option value="Medium" selected>Medium</option>
          <option value="Hard">Hard</option>
          <option value="Boss Level">Boss ⚔️</option>
        </select>
        <button onclick="addOnboardingSubject()" class="btn btn-secondary">Add</button>
      </div>
      <button onclick="saveOnboardingStep3()" class="btn btn-primary" style="width: 100%;">Next: Subject Topics & Chapters ➡️</button>
    `;
    renderOnboardingSubjectsList();
  } else if (onboardingStep === 4) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 2.5rem;">📖</span>
        <h2 style="font-weight: 800;">Step 4 of 8: Add Topics & Chapters</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">Add specific topics for your subjects</p>
      </div>
      <div id="onb-topics-subj-selector" style="margin-bottom: 1rem;"></div>
      <div class="form-group">
        <label>Topic Name</label>
        <input type="text" id="onb-topic-name" class="form-control" placeholder="e.g. Linked Lists & Trees">
      </div>
      <button onclick="addOnboardingTopic()" class="btn btn-secondary" style="width: 100%; margin-bottom: 1rem;">➕ Add Topic to Selected Subject</button>
      <div id="onb-added-topics-preview" style="max-height: 150px; overflow-y: auto; margin-bottom: 1.5rem;"></div>
      <button onclick="onboardingStep=5; renderOnboardingStep();" class="btn btn-primary" style="width: 100%;">Next: Available Study Hours ➡️</button>
    `;
    renderOnboardingTopicSubjSelector();
  } else if (onboardingStep === 5) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 2.5rem;">⏳</span>
        <h2 style="font-weight: 800;">Step 5 of 8: Daily Study Hours</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">How many hours per day can you commit to studying?</p>
      </div>
      <div style="text-align: center; margin: 2rem 0;">
        <span id="onb-hours-display" style="font-size: 3.5rem; font-weight: 800; color: var(--accent-gold);">3.0 Hours</span>
        <input type="range" min="1" max="10" step="0.5" value="3.0" id="onb-hours-slider" class="form-control" oninput="document.getElementById('onb-hours-display').innerText = this.value + ' Hours';" style="margin-top: 1rem;">
      </div>
      <button onclick="saveOnboardingStep5()" class="btn btn-primary" style="width: 100%;">Next: Preferred Time ➡️</button>
    `;
  } else if (onboardingStep === 6) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 2.5rem;">🌙</span>
        <h2 style="font-weight: 800;">Step 6 of 8: Preferred Study Time</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">When are you most focused?</p>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
        <button class="btn btn-secondary" style="padding: 1.5rem;" onclick="saveOnboardingStep6('Morning')">🌅 Morning</button>
        <button class="btn btn-secondary" style="padding: 1.5rem;" onclick="saveOnboardingStep6('Afternoon')">☀️ Afternoon</button>
        <button class="btn btn-secondary" style="padding: 1.5rem;" onclick="saveOnboardingStep6('Evening')">🌆 Evening</button>
        <button class="btn btn-secondary" style="padding: 1.5rem;" onclick="saveOnboardingStep6('Night')">🌌 Night</button>
      </div>
    `;
  } else if (onboardingStep === 7) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 3rem; animation: spin 2s linear infinite;">⚙️</span>
        <h2 style="font-weight: 800;">Step 7 of 8: Generating Study Plan</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">StudyQuest AI is dividing your study hours intelligently...</p>
      </div>
      <div class="progress-container" style="margin: 2rem 0;">
        <div class="progress-bar" style="width: 100%;"></div>
      </div>
      <button onclick="finishOnboardingAndGenerate()" class="btn btn-gold" style="width: 100%; padding: 1rem; font-size: 1.1rem;">
        Finalize Quest Plan 🚀
      </button>
    `;
  } else if (onboardingStep === 8) {
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem;">
        <span style="font-size: 4rem;">🎮</span>
        <h2 style="font-weight: 800; font-size: 2rem; color: var(--accent-gold);">YOUR ADVENTURE BEGINS!</h2>
        <p style="color: var(--text-secondary); font-size: 1rem; margin-top: 0.5rem;">Your first study quest is ready. Complete tasks, earn XP, and climb to Level 100!</p>
      </div>
      <button onclick="completeOnboardingFlow()" class="btn btn-gold" style="width: 100%; padding: 1rem; font-size: 1.1rem;">
        START QUEST ⚔️
      </button>
    `;
  }
}

function saveOnboardingStep2() {
  tempOnboardingData.name = document.getElementById('onb-name').value;
  tempOnboardingData.yearOfStudy = document.getElementById('onb-year').value;
  tempOnboardingData.course = document.getElementById('onb-course').value;
  tempOnboardingData.college = document.getElementById('onb-college').value;
  
  // Default sample subjects if none
  if (tempOnboardingData.subjects.length === 0) {
    tempOnboardingData.subjects = [
      { name: 'Data Structures', difficulty: 'Hard', topics: ['Linked Lists', 'Binary Trees', 'Graphs'] },
      { name: 'Operating Systems', difficulty: 'Medium', topics: ['Process Scheduling', 'Memory Management'] },
      { name: 'Mathematics', difficulty: 'Medium', topics: ['Linear Algebra', 'Calculus'] }
    ];
  }
  onboardingStep = 3;
  renderOnboardingStep();
}

function renderOnboardingSubjectsList() {
  const container = document.getElementById('onb-subj-list');
  if (!container) return;
  container.innerHTML = tempOnboardingData.subjects.map((s, idx) => `
    <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(13,19,33,0.6); padding: 0.6rem 1rem; border-radius: var(--radius-md);">
      <div><strong>${s.name}</strong> <span style="font-size: 0.75rem; color: var(--accent-gold);">(${s.difficulty})</span></div>
      <button onclick="removeOnboardingSubject(${idx})" class="btn btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.75rem;">✕</button>
    </div>
  `).join('');
}

function addOnboardingSubject() {
  const name = document.getElementById('onb-new-subj').value.trim();
  const diff = document.getElementById('onb-new-diff').value;
  if (!name) return;
  tempOnboardingData.subjects.push({ name, difficulty: diff, topics: [] });
  document.getElementById('onb-new-subj').value = '';
  renderOnboardingSubjectsList();
}

function removeOnboardingSubject(idx) {
  tempOnboardingData.subjects.splice(idx, 1);
  renderOnboardingSubjectsList();
}

function saveOnboardingStep3() {
  if (tempOnboardingData.subjects.length === 0) {
    alert('Please add at least one subject!');
    return;
  }
  onboardingStep = 4;
  renderOnboardingStep();
}

function renderOnboardingTopicSubjSelector() {
  const container = document.getElementById('onb-topics-subj-selector');
  if (!container) return;
  container.innerHTML = `
    <label>Select Subject</label>
    <select id="onb-active-subj-idx" class="form-control">
      ${tempOnboardingData.subjects.map((s, idx) => `<option value="${idx}">${s.name}</option>`).join('')}
    </select>
  `;
}

function addOnboardingTopic() {
  const idx = document.getElementById('onb-active-subj-idx').value;
  const name = document.getElementById('onb-topic-name').value.trim();
  if (!name) return;
  tempOnboardingData.subjects[idx].topics.push(name);
  document.getElementById('onb-topic-name').value = '';
  
  const preview = document.getElementById('onb-added-topics-preview');
  preview.innerHTML += `<div style="font-size: 0.85rem; color: var(--accent-cyan);">✅ Added: ${tempOnboardingData.subjects[idx].name} -> ${name}</div>`;
}

function saveOnboardingStep5() {
  tempOnboardingData.dailyStudyHours = parseFloat(document.getElementById('onb-hours-slider').value);
  onboardingStep = 6;
  renderOnboardingStep();
}

function saveOnboardingStep6(pref) {
  tempOnboardingData.preferredStudyTime = pref;
  onboardingStep = 7;
  renderOnboardingStep();
}

async function finishOnboardingAndGenerate() {
  // Save profile
  await fetch('/api/profile/onboarding', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: tempOnboardingData.name,
      yearOfStudy: tempOnboardingData.yearOfStudy,
      course: tempOnboardingData.course,
      college: tempOnboardingData.college,
      dailyStudyHours: tempOnboardingData.dailyStudyHours,
      preferredStudyTime: tempOnboardingData.preferredStudyTime
    })
  });

  // Save subjects & topics
  for (const s of tempOnboardingData.subjects) {
    const res = await fetch('/api/subjects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: s.name, difficulty: s.difficulty })
    });
    if (res.ok) {
      const savedSubj = await res.json();
      for (const t of s.topics) {
        await fetch(`/api/subjects/${savedSubj.id}/topics`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: t })
        });
      }
    }
  }

  // Generate initial study plan
  await fetch('/api/quests/generate', { method: 'POST' });

  onboardingStep = 8;
  renderOnboardingStep();
}

function completeOnboardingFlow() {
  document.getElementById('onboarding-screen').classList.remove('active');
  document.getElementById('app-container').style.display = 'flex';
  checkAuth();
}

// ==========================================================================
// VIEW NAVIGATION
// ==========================================================================
function showView(viewName) {
  currentView = viewName;
  document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-btn').forEach(el => el.classList.remove('active'));

  const activeSec = document.getElementById('view-' + viewName);
  if (activeSec) activeSec.classList.add('active');

  document.querySelectorAll(`[data-view="${viewName}"]`).forEach(btn => btn.classList.add('active'));

  if (viewName === 'home') loadHomeData();
  else if (viewName === 'adventure') loadAdventureMap();
  else if (viewName === 'subjects') loadSubjectsView();
  else if (viewName === 'timer') loadTimerView();
  else if (viewName === 'profile') loadProfileView();
}

// ==========================================================================
// VIEW 1: HOME DASHBOARD
// ==========================================================================
async function loadHomeData() {
  if (!currentUser) return;
  document.getElementById('home-greeting').innerText = `Good Morning, ${currentUser.name || currentUser.username} 👋`;
  document.getElementById('home-streak-val').innerText = `${currentUser.currentStreak} Days`;
  document.getElementById('home-level-val').innerText = `Level ${currentUser.currentLevel}`;

  // Check rescheduling
  try {
    const rRes = await fetch('/api/quests/reschedule', { method: 'POST' });
    if (rRes.ok) {
      const rData = await rRes.json();
      if (rData.rescheduledCount > 0) {
        document.getElementById('reschedule-banner').style.display = 'block';
        document.getElementById('reschedule-banner-msg').innerText = rData.message;
      }
    }
  } catch (e) {}

  // Fetch today's quests & stats
  try {
    const qRes = await fetch('/api/quests/today');
    if (qRes.ok) {
      const data = await qRes.json();
      renderTodayQuests(data.quests);
    }

    const tRes = await fetch('/api/timer/stats');
    if (tRes.ok) {
      const stats = await tRes.json();
      const mins = stats.todayMinutes || 0;
      const hrs = Math.floor(mins / 60);
      const remMins = mins % 60;
      document.getElementById('home-study-time').innerText = `${hrs}h ${remMins}m / ${currentUser.dailyStudyHours}h`;
    }

    // Update XP bar
    const pRes = await fetch('/api/profile');
    if (pRes.ok) {
      const pData = await pRes.json();
      const user = pData.user;
      const nextXp = pData.nextLevelXp;
      const pct = Math.min(100, Math.round((user.totalXp / nextXp) * 100));
      document.getElementById('home-xp-val').innerText = `${user.totalXp.toLocaleString()} / ${nextXp.toLocaleString()} XP`;
      document.getElementById('home-xp-bar').style.width = pct + '%';
      document.getElementById('home-adventure-sub').innerText = `Level ${user.currentLevel}: ${user.currentLevel <= 10 ? 'Starting Village' : 'Knowledge Realm'}`;
    }
  } catch (e) { console.log(e); }
}

function renderTodayQuests(quests) {
  const container = document.getElementById('today-quests-container');
  if (!quests || quests.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 2rem; color: var(--text-secondary);">
        🎉 All daily quests completed! Click <strong>Re-generate Plan</strong> to generate more study quests.
      </div>
    `;
    return;
  }

  container.innerHTML = quests.map(q => `
    <div class="quest-item ${q.completed ? 'completed' : ''}">
      <div class="quest-left">
        <div class="quest-checkbox" onclick="toggleQuestComplete(${q.id}, ${q.completed})">
          ${q.completed ? '✓' : ''}
        </div>
        <div>
          <div class="quest-title">${q.title}</div>
          <div class="quest-sub">📖 ${q.learningMethod || 'Read concepts'} | ⏱️ ${q.durationMinutes} mins</div>
        </div>
      </div>
      <div class="quest-badge">+${q.xpReward} XP</div>
    </div>
  `).join('');
}

async function toggleQuestComplete(questId, isCompleted) {
  if (isCompleted) return;
  try {
    const res = await fetch(`/api/quests/${questId}/complete`, { method: 'POST' });
    if (res.ok) {
      const data = await res.json();
      playChimeSound();

      if (data.xpResult && data.xpResult.leveledUp) {
        showLevelUpModal(data.xpResult.newLevel);
      }

      currentUser.totalXp = data.xpResult.newXp;
      currentUser.currentLevel = data.xpResult.newLevel;
      currentUser.currentStreak = data.streakResult.currentStreak;
      updateNavProfile();
      loadHomeData();
    }
  } catch (e) { console.log(e); }
}

async function triggerGeneratePlan() {
  await fetch('/api/quests/generate', { method: 'POST' });
  loadHomeData();
}

function hideRescheduleBanner() {
  document.getElementById('reschedule-banner').style.display = 'none';
}

// ==========================================================================
// VIEW 2: ADVENTURE MAP (100 LEVELS)
// ==========================================================================
async function loadAdventureMap() {
  try {
    const res = await fetch('/api/adventure/map');
    if (res.ok) {
      const data = await res.json();
      document.getElementById('map-current-lvl-badge').innerText = `Current: Level ${data.currentLevel}`;
      renderAdventureMap(data.levels, data.currentLevel);
    }
  } catch (e) { console.log(e); }
}

function renderAdventureMap(levels, userLevel) {
  const container = document.getElementById('adventure-map-container');
  // Group levels by zone
  const zonesMap = {};
  levels.forEach(l => {
    if (!zonesMap[l.zoneName]) zonesMap[l.zoneName] = [];
    zonesMap[l.zoneName].push(l);
  });

  container.innerHTML = Object.keys(zonesMap).map(zone => `
    <div class="zone-block">
      <div class="zone-header">
        <span>${zonesMap[zone][0].icon} ${zone}</span>
      </div>
      <div class="nodes-row">
        ${zonesMap[zone].map(l => `
          <div class="level-node ${l.unlocked ? 'unlocked' : 'locked'} ${l.level === userLevel ? 'current' : ''}" onclick="inspectLevel(${l.level}, ${l.unlocked})">
            <span class="level-node-icon">${l.icon}</span>
            <span class="level-node-num">Level ${l.level}</span>
            <span class="level-node-title">${l.title}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

function inspectLevel(level, unlocked) {
  if (level % 10 === 0 || level === 1) {
    openBossQuizModal(level);
  } else {
    alert(`🗺️ Level ${level}\nRequirement: ${unlocked ? 'Unlocked & Active' : 'Locked - Reach Level ' + (level - 1) + ' first!'}`);
  }
}

// ==========================================================================
// VIEW 3: SUBJECTS MANAGER
// ==========================================================================
async function loadSubjectsView() {
  try {
    const res = await fetch('/api/subjects');
    if (res.ok) {
      const subjects = await res.json();
      renderSubjectsGrid(subjects);
      populateTimerSubjectDropdown(subjects);
    }
  } catch (e) { console.log(e); }
}

function renderSubjectsGrid(subjects) {
  const container = document.getElementById('subjects-grid');
  if (!subjects || subjects.length === 0) {
    container.innerHTML = `<div style="color: var(--text-secondary);">No subjects added yet. Click <strong>Add Subject</strong> to begin!</div>`;
    return;
  }

  container.innerHTML = subjects.map(item => {
    const s = item.subject;
    const topics = item.topics;
    return `
      <div class="card" style="border-left: 4px solid ${s.color || '#6366f1'};">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div>
            <h3 style="font-weight: 800; font-size: 1.15rem;">${s.name}</h3>
            <span class="quest-badge" style="font-size: 0.75rem;">${s.difficulty}</span>
          </div>
          <button onclick="deleteSubject(${s.id})" class="btn btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.75rem;">🗑️</button>
        </div>

        <div style="margin: 1rem 0; font-size: 0.85rem; color: var(--text-secondary);">
          <div>Knowledge Level: ${s.currentKnowledgeLevel} / 10</div>
          <div>Exam Date: ${s.examDate || 'Not set'}</div>
        </div>

        <div style="border-top: 1px solid var(--border-color); padding-top: 0.75rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <strong style="font-size: 0.85rem;">Topics (${topics.length})</strong>
            <button onclick="openAddTopicModal(${s.id})" class="btn btn-secondary" style="padding: 0.2rem 0.6rem; font-size: 0.75rem;">➕ Topic</button>
          </div>

          <div style="display: flex; flex-direction: column; gap: 0.4rem; max-height: 120px; overflow-y: auto;">
            ${topics.map(t => `
              <div style="font-size: 0.8rem; display: flex; justify-content: space-between; background: rgba(13,19,33,0.4); padding: 0.3rem 0.6rem; border-radius: 4px;">
                <span>${t.isCompleted ? '✅' : '📖'} ${t.name}</span>
                <span style="color: var(--text-muted); font-size: 0.7rem;">${t.recommendedMethod}</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function openAddSubjectModal() {
  document.getElementById('subject-modal').classList.add('active');
}

async function handleAddSubjectSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('subj-name').value;
  const difficulty = document.getElementById('subj-diff').value;
  const examDate = document.getElementById('subj-exam').value || null;
  const currentKnowledgeLevel = parseInt(document.getElementById('subj-knowledge').value) || 5;

  await fetch('/api/subjects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, difficulty, examDate, currentKnowledgeLevel })
  });

  closeModal('subject-modal');
  loadSubjectsView();
  triggerGeneratePlan();
}

async function deleteSubject(id) {
  if (confirm('Delete this subject and all its topics?')) {
    await fetch(`/api/subjects/${id}`, { method: 'DELETE' });
    loadSubjectsView();
    triggerGeneratePlan();
  }
}

function openAddTopicModal(subjId) {
  document.getElementById('topic-subj-id').value = subjId;
  document.getElementById('topic-modal').classList.add('active');
}

async function handleAddTopicSubmit(e) {
  e.preventDefault();
  const subjId = document.getElementById('topic-subj-id').value;
  const name = document.getElementById('topic-name').value;
  const chapter = document.getElementById('topic-chapter').value;
  const recommendedMethod = document.getElementById('topic-method').value;

  await fetch(`/api/subjects/${subjId}/topics`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, chapter, recommendedMethod })
  });

  closeModal('topic-modal');
  loadSubjectsView();
  triggerGeneratePlan();
}

// ==========================================================================
// VIEW 4: FOCUS TIMER ENGINE
// ==========================================================================
function loadTimerView() {
  updateTimerDisplay();
  loadTimerStats();
}

function setTimerMode(mode) {
  if (isTimerRunning) return;
  currentTimerMode = mode;
  document.getElementById('mode-focus').className = mode === 'FOCUS' ? 'btn btn-primary' : 'btn btn-secondary';
  document.getElementById('mode-deep').className = mode === 'DEEP' ? 'btn btn-primary' : 'btn btn-secondary';
  document.getElementById('mode-custom').className = mode === 'CUSTOM' ? 'btn btn-primary' : 'btn btn-secondary';

  if (mode === 'FOCUS') timerSeconds = 1500; // 25m
  else if (mode === 'DEEP') timerSeconds = 3000; // 50m
  else if (mode === 'CUSTOM') {
    const mins = prompt('Enter custom timer duration in minutes:', '20');
    timerSeconds = (parseInt(mins) || 20) * 60;
  }
  timerTotalSeconds = timerSeconds;
  updateTimerDisplay();
}

function updateTimerDisplay() {
  const m = Math.floor(timerSeconds / 60);
  const s = timerSeconds % 60;
  document.getElementById('timer-clock').innerText = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  document.getElementById('timer-mode-label').innerText = currentTimerMode + ' QUEST';
}

function startTimer() {
  if (isTimerRunning) return;
  isTimerRunning = true;
  document.getElementById('timer-start-btn').style.display = 'none';
  document.getElementById('timer-pause-btn').style.display = 'inline-flex';
  document.getElementById('timer-stop-btn').style.display = 'inline-flex';
  document.getElementById('timer-target-lbl').innerText = 'Focusing... Stay on quest!';

  timerInterval = setInterval(() => {
    if (timerSeconds > 0) {
      timerSeconds--;
      updateTimerDisplay();
    } else {
      finishTimerSession();
    }
  }, 1000);
}

function pauseTimer() {
  isTimerRunning = false;
  clearInterval(timerInterval);
  document.getElementById('timer-start-btn').style.display = 'inline-flex';
  document.getElementById('timer-pause-btn').style.display = 'none';
  document.getElementById('timer-target-lbl').innerText = 'Timer Paused';
}

function resetTimer() {
  pauseTimer();
  setTimerMode(currentTimerMode);
  document.getElementById('timer-stop-btn').style.display = 'none';
  document.getElementById('timer-target-lbl').innerText = 'Ready to study';
}

function stopTimer() {
  pauseTimer();
  finishTimerSession();
}

async function finishTimerSession() {
  clearInterval(timerInterval);
  isTimerRunning = false;
  playChimeSound();

  const elapsedMins = Math.max(1, Math.round((timerTotalSeconds - timerSeconds) / 60));
  const subjSelect = document.getElementById('timer-subject-select');
  const subjectName = subjSelect ? subjSelect.value : 'General Focus';

  try {
    const res = await fetch('/api/timer/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subjectName,
        topicName: 'Focus Session',
        durationMinutes: elapsedMins,
        mode: currentTimerMode
      })
    });

    if (res.ok) {
      const data = await res.json();
      alert(`🎉 Focus Session Logged!\nYou completed ${elapsedMins} mins of study and earned +${data.session.xpEarned} XP!`);
      if (data.xpResult && data.xpResult.leveledUp) {
        showLevelUpModal(data.xpResult.newLevel);
      }
      currentUser.totalXp = data.xpResult.newXp;
      currentUser.currentLevel = data.xpResult.newLevel;
      updateNavProfile();
      resetTimer();
      loadTimerStats();
    }
  } catch (e) { console.log(e); }
}

async function loadTimerStats() {
  try {
    const res = await fetch('/api/timer/stats');
    if (res.ok) {
      const stats = await res.json();
      document.getElementById('timer-stat-today').innerText = `${stats.todayMinutes || 0} mins`;
      document.getElementById('timer-stat-week').innerText = `${stats.weekMinutes || 0} mins`;
      document.getElementById('timer-stat-total').innerText = `${Math.round((stats.totalMinutes || 0) / 60)} hrs`;
    }
  } catch (e) {}
}

function populateTimerSubjectDropdown(subjects) {
  const select = document.getElementById('timer-subject-select');
  if (!select) return;
  select.innerHTML = '<option value="General Focus Study">General Focus Study</option>' + 
    subjects.map(s => `<option value="${s.subject.name}">${s.subject.name}</option>`).join('');
}

// ==========================================================================
// VIEW 5: PROFILE & ACHIEVEMENTS
// ==========================================================================
async function loadProfileView() {
  try {
    const res = await fetch('/api/profile');
    if (res.ok) {
      const data = await res.json();
      const user = data.user;
      const badges = data.badges;

      document.getElementById('profile-name').innerText = user.name || user.username;
      document.getElementById('profile-course').innerText = user.course || 'Degree Course';
      document.getElementById('profile-year-college').innerText = `${user.yearOfStudy || 'Student'} | ${user.college || 'College'}`;
      document.getElementById('profile-level').innerText = `Level ${user.currentLevel}`;
      document.getElementById('profile-xp').innerText = `${user.totalXp.toLocaleString()} XP`;
      document.getElementById('profile-streak').innerText = `${user.currentStreak} Days 🔥`;
      document.getElementById('profile-longest-streak').innerText = `${user.longestStreak} Days`;

      renderBadgesGrid(badges);
    }

    const tRes = await fetch('/api/timer/stats');
    if (tRes.ok) {
      const tData = await tRes.json();
      renderSessionHistory(tData.recentSessions || []);
    }
  } catch (e) { console.log(e); }
}

function renderBadgesGrid(earnedBadges) {
  const container = document.getElementById('badges-grid');
  const earnedKeys = new Set(earnedBadges.map(b => b.badgeKey));

  const allBadges = [
    { key: 'FIRST_STEP', title: 'First Step', desc: 'Complete Level 1', icon: '🌱' },
    { key: 'STREAK_3', title: '3-Day Bronze', desc: '3 Day Streak', icon: '🥉' },
    { key: 'STREAK_7', title: '7-Day Silver', desc: '7 Day Streak', icon: '🥈' },
    { key: 'STREAK_14', title: '14-Day Gold', desc: '14 Day Streak', icon: '🥇' },
    { key: 'STREAK_30', title: 'Fire Master', desc: '30 Day Streak', icon: '🔥' },
    { key: 'STREAK_60', title: 'Study Warrior', desc: '60 Day Streak', icon: '⚔️' },
    { key: 'STREAK_100', title: 'Legendary Scholar', desc: '100 Day Streak', icon: '👑' },
    { key: 'FOREST_NAVIGATOR', title: 'Forest Navigator', desc: 'Reach Level 10', icon: '🌲' },
    { key: 'CONCEPT_MASTER', title: 'Concept Master', desc: 'Reach Level 25', icon: '🧠' },
    { key: 'GALAXY_SCHOLAR', title: 'Galaxy Scholar', desc: 'Reach Level 50', icon: '🌌' },
    { key: 'STUDY_MASTER', title: 'Study Master', desc: 'Reach Level 100', icon: '🏆' }
  ];

  container.innerHTML = allBadges.map(b => {
    const isUnlocked = earnedKeys.has(b.key);
    return `
      <div style="background: rgba(13,19,33,0.6); border: 1px solid ${isUnlocked ? 'var(--accent-gold)' : 'var(--border-color)'}; padding: 1rem 0.5rem; border-radius: var(--radius-md); text-align: center; opacity: ${isUnlocked ? 1 : 0.4}; filter: ${isUnlocked ? 'none' : 'grayscale(100%)'};">
        <div style="font-size: 2rem;">${b.icon}</div>
        <div style="font-weight: 700; font-size: 0.8rem; margin-top: 0.4rem;">${b.title}</div>
        <div style="font-size: 0.7rem; color: var(--text-secondary);">${b.desc}</div>
      </div>
    `;
  }).join('');
}

function renderSessionHistory(sessions) {
  const container = document.getElementById('session-history-list');
  if (!sessions || sessions.length === 0) {
    container.innerHTML = '<div style="color: var(--text-secondary); font-size: 0.85rem;">No study sessions recorded yet. Use the timer to record study sessions!</div>';
    return;
  }
  container.innerHTML = sessions.map(s => `
    <div style="display: flex; justify-content: space-between; background: rgba(13,19,33,0.4); padding: 0.5rem 0.8rem; border-radius: 6px; font-size: 0.85rem;">
      <div>⏱️ <strong>${s.subjectName}</strong> (${s.durationMinutes} mins)</div>
      <div style="color: var(--accent-gold); font-weight: 700;">+${s.xpEarned} XP</div>
    </div>
  `).join('');
}

function toggleEditProfile() {
  const box = document.getElementById('edit-profile-box');
  box.style.display = box.style.display === 'none' ? 'block' : 'none';
  if (currentUser) {
    document.getElementById('edit-name').value = currentUser.name || '';
    document.getElementById('edit-year').value = currentUser.yearOfStudy || '';
    document.getElementById('edit-course').value = currentUser.course || '';
    document.getElementById('edit-college').value = currentUser.college || '';
    document.getElementById('edit-hours').value = currentUser.dailyStudyHours || 3.0;
  }
}

async function saveProfileEdit() {
  const name = document.getElementById('edit-name').value;
  const yearOfStudy = document.getElementById('edit-year').value;
  const course = document.getElementById('edit-course').value;
  const college = document.getElementById('edit-college').value;
  const dailyStudyHours = parseFloat(document.getElementById('edit-hours').value);

  const res = await fetch('/api/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, yearOfStudy, course, college, dailyStudyHours })
  });

  if (res.ok) {
    currentUser = await res.json();
    toggleEditProfile();
    loadProfileView();
    updateNavProfile();
  }
}

// ==========================================================================
// MODALS MANAGEMENT
// ==========================================================================
function closeModal(id) {
  document.getElementById(id).classList.remove('active');
}

function showLevelUpModal(newLevel) {
  document.getElementById('levelup-title').innerText = `You reached Level ${newLevel}!`;
  document.getElementById('levelup-modal').classList.add('active');
}

async function openBossQuizModal(level) {
  try {
    const res = await fetch(`/api/adventure/boss-quiz/${level}`);
    if (res.ok) {
      const questions = await res.json();
      renderBossQuiz(questions, level);
      document.getElementById('quiz-modal').classList.add('active');
    }
  } catch (e) { console.log(e); }
}

function renderBossQuiz(questions, level) {
  const body = document.getElementById('quiz-modal-body');
  document.getElementById('quiz-modal-title').innerText = `⚔️ Level ${level} Boss Challenge`;
  if (!questions || questions.length === 0) {
    body.innerHTML = '<div>No quiz available for this level yet!</div>';
    return;
  }

  const q = questions[0];
  body.innerHTML = `
    <div style="font-weight: 700; font-size: 1.1rem; margin-bottom: 1rem;">${q.question}</div>
    <div style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1.5rem;">
      ${q.options.map((opt, idx) => `
        <button onclick="submitBossAnswer(0, ${idx}, ${q.correctIndex}, '${q.explanation.replace(/'/g, "\\'")}')" class="btn btn-secondary" style="text-align: left; padding: 0.8rem 1rem;">
          ${String.fromCharCode(65 + idx)}. ${opt}
        </button>
      `).join('')}
    </div>
    <div id="quiz-feedback-box" style="display: none; font-size: 0.9rem; padding: 1rem; border-radius: var(--radius-md);"></div>
  `;
}

async function submitBossAnswer(qIdx, selectedIdx, correctIdx, explanation) {
  const feedbackBox = document.getElementById('quiz-feedback-box');
  feedbackBox.style.display = 'block';

  const res = await fetch('/api/adventure/boss-quiz/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ questionIndex: qIdx, selectedIndex: selectedIdx, correctIndex: correctIdx })
  });

  if (res.ok) {
    const data = await res.json();
    if (data.correct) {
      playChimeSound();
      feedbackBox.style.background = 'rgba(16, 185, 129, 0.15)';
      feedbackBox.style.border = '1px solid var(--accent-success)';
      feedbackBox.innerHTML = `
        <strong style="color: var(--accent-success);">⚔️ Correct! (+30 XP)</strong>
        <p style="margin-top: 0.4rem; color: var(--text-secondary);">${explanation}</p>
      `;
      if (data.xpResult && data.xpResult.leveledUp) {
        setTimeout(() => showLevelUpModal(data.xpResult.newLevel), 1500);
      }
    } else {
      feedbackBox.style.background = 'rgba(239, 68, 68, 0.15)';
      feedbackBox.style.border = '1px solid var(--accent-danger)';
      feedbackBox.innerHTML = `
        <strong style="color: var(--accent-danger);">Incorrect Answer</strong>
        <p style="margin-top: 0.4rem; color: var(--text-secondary);">${explanation}</p>
      `;
    }
  }
}
