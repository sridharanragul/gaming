package com.studyquest.studyquest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyQuestApplicationTests {

	@Test
	void contextLoads() {
	}

}
